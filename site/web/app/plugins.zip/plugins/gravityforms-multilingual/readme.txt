=== Gravity Forms Multilingual ===
Stable tag: 1.7.2