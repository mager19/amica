<?php
/**
 * Our greatest weakness lies in giving up.
 * The most certain way to succeed is always to try just one more time.
 *
 * - Thomas A. Edison
 */
